package com.petstore.bddsamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepsSignin {
	WebDriver wd;
	public void init(WebDriver wd) {
		 this.wd=wd;
		 
	 }
	
	@Given("The user is in login page")
	public void loginpage() {
		wd = new FirefoxDriver();
		wd.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
	
	}
	
	@When("^The user enters \"$username\"$")
	public void Enter_username(String unm) {
		wd.findElement(By.xpath("//*[@name='username']")).clear();
		wd.findElement(By.xpath("//*[@name='username']")).sendKeys(unm);
		
	}
	@When("The user enters password")
	public void Enter_password(String pwd) {
		wd.findElement(By.xpath("//*[@name='password']")).clear();
		wd.findElement(By.xpath("//*[@name='password']")).sendKeys(pwd);
	}
	@When("The user clicks on login")
	public void clicklogin() {
		//wd.findElement(By.xpath("//*[@name='password']"))
		wd.findElement(By.xpath("//*[@name='signon']")).click();
	}
	
	@Then("The user gets the login successful message")
	public void Success() {
		System.out.println("Pass");
	}
	
	
	

}
