package Test;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePage_Test1_Script {
	WebDriver wd;
	String pgTitle1;
	
	@Given("The user must be in home page of jpetstore")
	//method
	public void The_user_must_be_in_home_page_of_jpetstore() {
		
		wd.get("https://petstore.octoperf.com/actions/Catalog.action");
		
	}
	
	@When("The user extracts the page title")
	//method
	public void The_user_extracts_the_page_title() {
		pgTitle1 = wd.getTitle();
		System.out.println("The page title is"+ " "+pgTitle1);
		
		
		
	} 
	
	@And("The user validate successfully")
	public void The_user_validate_successfully() {
		
	}
	
    @Then("The application is invoked successfully")
    public void Then_The_application_is_invoked_successfully() {
    	
    }


}
